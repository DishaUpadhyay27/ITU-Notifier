package com.example.priyanka.notification;

import android.os.Bundle;
import android.os.StrictMode;

import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;


public class SubscriptionActivity extends AppCompatActivity {

    public static final String url = "jdbc:mysql://192.168.1.145:3306/Announcement";
    public static final String username = "root";
    public static final String password = "root123";
    Statement stmt;

    String categories;
    Button subscribe;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> categoryList = new ArrayList<String>();
    ArrayList<String> selectedCategoryList = new ArrayList<String>();
    // ArrayList<String> categoryCheckedList = new ArrayList<String>(); //
    public static int userID = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        //this is for showing category
        categories = showCategory();
        categories = categories.substring(0, categories.length() - 2);
        categories = categories.trim();
        String[] categoryArray = categories.split(",");
        for (int i = 0; i < categoryArray.length; i++) {
            categoryList.add(categoryArray[i]);
        }

        //this is for checking category
      /*  String categoriesChecked = setCategory();
        categoriesChecked = categoriesChecked.substring(0, categoriesChecked.length() - 2);
        categoriesChecked = categoriesChecked.trim();
        String[] categorycheckArray = categories.split(",");
        for (int i = 0; i < categorycheckArray.length; i++) {
            categoryCheckedList.add(categorycheckArray[i]);
        }
        */

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, categoryList);
        listView.setAdapter(adapter);
        View.OnClickListener listenerSub = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /** Getting the checked items from the listview */

                try {
                    SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
                    int itemCount = listView.getCount();

                    for (int i = itemCount - 1; i >= 0; i--) {
                        if (checkedItemPositions.get(i)) {
                            selectedCategoryList.add(categoryList.get(i));
                        }
                    }
                    getCategoryId();
                    Toast.makeText(v.getContext(), "Subscribed Successfully", Toast.LENGTH_LONG).show();
                } catch (Exception e) {

                }
            }
        };

        /** Setting the event listener for the add button */
        subscribe.setOnClickListener(listenerSub);


    }

//show categories from database
    public String showCategory() {
        try {
            String data = "";
            stmt = Announcements.connectDB();
            ResultSet rs = stmt.executeQuery("SELECT * FROM category");
            ResultSet rs2=  stmt.executeQuery("SELECT * FROM usercategory");
            ResultSetMetaData rsm = rs.getMetaData();


            while (rs.next()) {
                if (!(rs.getString(2).isEmpty())) {
                    data = data + rs.getString(2) + ",";
                }
            }
            return data;

        } catch (Exception e) {
            // e.printStackTrace();
            return e.getMessage();

        }

    }

  /*  public String setCategory() {
        try {
            String data = "";
            stmt = Announcements.connectDB();

            ResultSet rs=  stmt.executeQuery("SELECT * FROM usercategory");
            ResultSetMetaData rsm = rs.getMetaData();


            while (rs.next()) {
                if (!(rs.getString(3).isEmpty())) {
                    data = data + rs.getString(3) + ",";
                }
            }
            return data;

        } catch (Exception e) {
            // e.printStackTrace();
            return e.getMessage();

        }

    }   */

    public void getCategoryId(){
        if (selectedCategoryList.size() > 0) {
            for (String category : selectedCategoryList) {
                    saveCategoryID(String.valueOf(categoryList.indexOf(category)+1));
                System.out.println("categoryList.indexOf(category)+1" + categoryList.indexOf(category) + 1);
                System.out.println("category"+category);
                }
            }
        }



    public  void saveCategoryID(String categoryID) {
        try {
            if(stmt.equals(null)){
                stmt = Announcements.connectDB();
            }

            String user_categoryID = String.valueOf(userID) + categoryID;
            String sql = "Insert into usercategory (USERCATEGORY_ID, USER_ID, CATEGORY_ID) Values (?, ?, ?)";
            PreparedStatement preparedStatement = Announcements.conn.prepareStatement(sql);
            preparedStatement.setString(1, user_categoryID);
            preparedStatement.setString(2, String.valueOf(userID));
            preparedStatement.setString(3, categoryID);


            preparedStatement.executeUpdate();


        } catch (Exception e) {
             e.printStackTrace();


        }


    }
}