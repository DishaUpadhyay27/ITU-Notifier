package com.example.priyanka.notification;


import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import java.sql.PreparedStatement;

import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.widget.Spinner;
import android.widget.Toast;

public class PostActivity extends AppCompatActivity {
    String title;
    String des;
    EditText editTit;
    private String category;
    List<String> categories;
    EditText editdes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        // Spinner element
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        // Spinner click listener


        // Spinner Drop down elements
        categories = new ArrayList<String>();
        categories.add("Sell");
        categories.add("Accomodation");
        categories.add("Lost and Found");
        categories.add("Fall 2016 Software Engineering ");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            protected Adapter initializedAdapter = null;


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // On selecting a spinner item
                category= parent.getItemAtPosition(position).toString();



                // Showing selected spinner item
                Toast.makeText(parent.getContext(), "Selected: " + category, Toast.LENGTH_LONG).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }

        });
        editTit = (EditText) findViewById(R.id.post_title);
        editdes= (EditText) findViewById(R.id.description);



        Button subButton = (Button) findViewById(R.id.subscribe);
        subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title= editTit.getText().toString();
                des= editdes.getText().toString();
                Log.d(des, title);
                if(title.equalsIgnoreCase("")){
                    editTit.setError("Please enter Post Title.");
                }
                if(des.equalsIgnoreCase("")){
                    editdes.setError("Please enter Post Details.");
                }
                if(!(title.equals(""))||des.equals(""))
                postDB(title, des);
                Toast.makeText(view.getContext(), "Notice Posted Successfully", Toast.LENGTH_LONG).show();
                editTit.setText("");
                editdes.setText("");

            }
        });



    }

    private void postDB(String title, String des) {
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            //get current date time with Date()
            Date date = new Date();
            System.out.println(dateFormat.format(date));
            int categoryID = categories.indexOf(category)+1;
            //get current date time with Calendar()

            String dateTime = dateFormat.format(date);
            Statement stmt = Announcements.connectDB();

            String sql = "Insert into announcement (USER_ID, DATE, CATEGORY,TITLE,DETAILS) Values (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = Announcements.conn.prepareStatement(sql);
            preparedStatement.setString(1, String.valueOf(SubscriptionActivity.userID));
            preparedStatement.setString(2, dateTime);
            preparedStatement.setString(3, category);
            preparedStatement.setString(4, title);
            preparedStatement.setString(5, des);
            preparedStatement.setString(6, String.valueOf(categoryID));





            preparedStatement.executeUpdate();


        } catch(Exception e){
           e.printStackTrace();
        }

    }

}
