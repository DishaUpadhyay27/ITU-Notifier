package com.example.priyanka.notification;


import android.os.Bundle;

import android.os.StrictMode;

import android.support.v7.app.AppCompatActivity;

import android.util.SparseBooleanArray;
import android.view.View;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;

import android.widget.ListView;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;


public class Announcements extends AppCompatActivity {

    public static final String url = "jdbc:mysql://192.168.1.145:3306/Announcement";
    public static final String username = "root";
    public static final String password = "root123";
    public static Connection conn;
    // Array of strings...
    String selectedItem;
    String notice;
    Button delete;
    CheckBox check;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> data = new ArrayList<String>();
    ArrayList<String> deletedList = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_annoucement);
        //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //  setSupportActionBar(toolbar);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //  setSupportActionBar(toolbar);
        notice = execute();
        notice = notice.substring(0, notice.length() - 2);
        notice = notice.trim();
        String[] noticeArray = notice.split(",");
        for (int i = 0; i < noticeArray.length; i++) {
            data.add(noticeArray[i]);
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, data);
        delete = (Button) findViewById(R.id.delete);
        listView = (ListView) findViewById(R.id.mobile_list);


        /** Defining a click event listener for the button "Delete" */
        View.OnClickListener listenerDel = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /** Getting the checked items from the listview */

                try {
                    SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
                    int itemCount = listView.getCount();

                    for (int i = itemCount - 1; i >= 0; i--) {
                        if (checkedItemPositions.get(i)) {
                            adapter.remove(data.get(i));
                        }
                    }
                    checkedItemPositions.clear();
                    adapter.notifyDataSetChanged();
                } catch (Exception e) {

                }
            }
        };

        /** Setting the event listener for the add button */
        delete.setOnClickListener(listenerDel);


        /** Setting the adapter to the ListView */
        listView.setAdapter(adapter);


    }

/*
    protected void RemoveItem(String item) {
        int i= data.indexOf(item);
        listView.removeViewAt(i);
        adapter.notifyDataSetChanged();
    }            */

    public static Statement connectDB() {
        Statement stmt = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, password);
            String result = "Datbase connection successful";

            stmt = conn.createStatement();


        } catch (Exception e) {

        }
        return stmt;
    }

    private String execute() {
        try {
            Statement stmt = connectDB();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Announcement");
            ResultSetMetaData rsm = rs.getMetaData();
            String data = "";

            while (rs.next()) {
                if (!(rs.getString(4).isEmpty() && rs.getString(5).isEmpty())) {
                    data = data + rs.getString(4) + " : " + rs.getString(5) + ",";
                }
            }
            return data;

        } catch (Exception e) {
            // e.printStackTrace();
            return e.getMessage();
        }

    }
}